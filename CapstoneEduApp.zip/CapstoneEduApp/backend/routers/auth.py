# backend/routers/auth.py

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from database import get_db
from utils.auth import (
    create_access_token,
    verify_refresh_token,
    delete_refresh_token  # 로그아웃용 함수 추가
)

router = APIRouter()

# ✅ Refresh Token 기반으로 Access Token 재발급
@router.post("/refresh")
def refresh_access_token(refresh_token: str, db: Session = Depends(get_db)):
    """
    클라이언트가 Refresh Token을 보낼 경우,
    해당 토큰이 DB에 존재하고 유효하면 새로운 Access Token을 발급합니다.
    """
    try:
        # Refresh Token의 유효성 검사
        user_id = verify_refresh_token(refresh_token, db)
        
        # 새로운 Access Token 생성
        new_access_token = create_access_token({"sub": str(user_id)})
        
        return {
            "access_token": new_access_token,
            "token_type": "bearer"
        }
    except HTTPException as e:
        raise e  # 오류 발생 시 그대로 HTTPException 반환

# ✅ 로그아웃 API – 전달된 Refresh Token을 DB에서 삭제
@router.post("/logout")
def logout(refresh_token: str, db: Session = Depends(get_db)):
    """
    클라이언트가 보낸 Refresh Token을 DB에서 삭제하여
    해당 사용자를 로그아웃 처리합니다.
    """
    try:
        # 1. 토큰이 유효한지 확인 (JWT 위조 방지)
        user_id = verify_refresh_token(refresh_token, db)

        # 2. DB에서 해당 Refresh Token 삭제
        delete_refresh_token(refresh_token, db)

        return {"message": "성공적으로 로그아웃되었습니다."}
    except HTTPException as e:
        raise e  # 유효하지 않거나 DB 삭제 오류가 발생하면 그대로 반환
