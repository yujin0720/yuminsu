# backend/database.py
from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
import os
from dotenv import load_dotenv

# .env 파일에서 환경변수 불러오기
load_dotenv()

# 📦 DATABASE_URL은 .env 파일에 저장된 DB 주소를 가져옴
DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./test.db")

# ✅ SQLite 연결 엔진 (기본 예제)
# 만약 MySQL을 사용한다면: 'mysql+pymysql://user:password@host/dbname'
engine = create_engine(
    DATABASE_URL,
    connect_args={"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {}
)

# 세션 생성기: DB 세션을 연결할 때 사용
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Base 클래스: 모든 모델들이 이걸 상속받아야 함
Base = declarative_base()

# Dependency로 사용할 DB 세션 함수 (라우터에서 Depends로 불러옴)
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
