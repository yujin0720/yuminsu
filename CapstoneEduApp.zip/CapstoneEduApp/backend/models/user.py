# backend/models/user.py
# 유저 테이블 모델
from sqlalchemy.orm import relationship  # ✅ 필요!
from sqlalchemy import Column, Integer, String, Date
from database import Base

class User(Base):
    __tablename__ = "user"

    user_id = Column(Integer, primary_key=True, autoincrement=True)
    login_id = Column(String(20), unique=True, nullable=False)
    password = Column(String(255), nullable=False)  # 또는 String(500)
    birthday = Column(Date)
    phone = Column(String(15))
    study_time_mon = Column(Integer)
    study_time_tue = Column(Integer)
    study_time_wed = Column(Integer)
    study_time_thu = Column(Integer)
    study_time_fri = Column(Integer)
    study_time_sat = Column(Integer)
    study_time_sun = Column(Integer)